$(document).ready(function(){
  $('.user-img').click(function () {
    $('.user-img').removeClass("active").css("opacity",1.0);
    $(this).addClass("active").css("opacity",0.75);
    var src = $(this).attr('src');
    var extension = src.substring(src.lastIndexOf(".")); // gets the extension
    var imageName = src.substring(0, src.lastIndexOf(".")); // gets the file name
    var altName = imageName.replace("images/thumbnails/", "");    
    var activeUser = altName;    
    $(".profile-content").css("display","none");
    $("#profile-" + activeUser).css("display","block");    
    var imageName1 = imageName.replace("thumbnails","main"); // replace the file path 
    $('#profile-img').attr('src', imageName1 + extension).attr('alt', "Profile " + altName);  
  });
});